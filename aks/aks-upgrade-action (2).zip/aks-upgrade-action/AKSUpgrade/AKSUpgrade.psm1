#Requires -PSEdition Core

# ── Dot-source all function files ──

# Private functions (helpers, not exported)
$privatePath = Join-Path $PSScriptRoot 'Private'
if (Test-Path $privatePath) {
    Get-ChildItem -Path $privatePath -Filter '*.ps1' -Recurse | ForEach-Object {
        . $_.FullName
    }
}

# Public functions (exported)
$publicPath = Join-Path $PSScriptRoot 'Public'
$publicFunctions = @()
if (Test-Path $publicPath) {
    Get-ChildItem -Path $publicPath -Filter '*.ps1' -Recurse | ForEach-Object {
        . $_.FullName
        $publicFunctions += $_.BaseName
    }
}

# Export only the public functions
Export-ModuleMember -Function $publicFunctions
