function Invoke-AzCli {
    <#
    .SYNOPSIS
        Wraps az CLI calls with consistent error handling and JSON deserialization.
    .PARAMETER Arguments
        Arguments to pass to the az CLI.
    .PARAMETER RawOutput
        If set, returns raw string output instead of parsed JSON.
    .PARAMETER ErrorMessage
        Custom error message if the command fails.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string[]] $Arguments,

        [switch] $RawOutput,

        [string] $ErrorMessage = "az CLI command failed."
    )

    $output = & az @Arguments 2>&1

    if ($LASTEXITCODE -ne 0) {
        $details = $output | Where-Object { $_ -is [System.Management.Automation.ErrorRecord] } | ForEach-Object { $_.ToString() }
        throw "$ErrorMessage`nExit code: $LASTEXITCODE`n$($details -join "`n")"
    }

    if ($RawOutput) {
        return ($output | Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] }) -join "`n"
    }

    $jsonString = ($output | Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] }) -join "`n"
    try {
        return $jsonString | ConvertFrom-Json
    }
    catch {
        return $jsonString
    }
}
