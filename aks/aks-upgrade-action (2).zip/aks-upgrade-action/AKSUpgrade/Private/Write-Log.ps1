function Write-Step {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "`n▶ $Message" -ForegroundColor Cyan
}

function Write-Ok {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "  ✔ $Message" -ForegroundColor Green
}

function Write-Warn {
    param([Parameter(Mandatory)][string]$Message)
    if ($env:GITHUB_ACTIONS -eq 'true') {
        Write-Host "::warning::$Message"
    }
    Write-Host "  ⚠ $Message" -ForegroundColor Yellow
}

function Write-Fail {
    param([Parameter(Mandatory)][string]$Message)
    if ($env:GITHUB_ACTIONS -eq 'true') {
        Write-Host "::error::$Message"
    }
    Write-Host "  ✘ $Message" -ForegroundColor Red
}

function Enter-LogGroup {
    param([Parameter(Mandatory)][string]$Title)
    if ($env:GITHUB_ACTIONS -eq 'true') {
        Write-Host "::group::$Title"
    }
    else {
        Write-Step $Title
    }
}

function Exit-LogGroup {
    if ($env:GITHUB_ACTIONS -eq 'true') {
        Write-Host "::endgroup::"
    }
}

function Write-ActionOutput {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Value
    )
    if ($env:GITHUB_OUTPUT) {
        "$Name=$Value" | Out-File -FilePath $env:GITHUB_OUTPUT -Append
    }
}
