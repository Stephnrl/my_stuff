BeforeAll {
    $modulePath = Join-Path $PSScriptRoot '..'
    Import-Module $modulePath -Force
}

Describe 'Resolve-AKSPatchVersion' {

    BeforeEach {
        Mock -ModuleName AKSUpgrade Enter-LogGroup {}
        Mock -ModuleName AKSUpgrade Exit-LogGroup {}
    }

    Context 'Multiple patch versions available' {

        BeforeEach {
            Mock -ModuleName AKSUpgrade Invoke-AzCli {
                [PSCustomObject]@{
                    controlPlaneProfile = [PSCustomObject]@{
                        upgrades = @(
                            [PSCustomObject]@{ kubernetesVersion = '1.32.0'; isPreview = $false },
                            [PSCustomObject]@{ kubernetesVersion = '1.32.2'; isPreview = $false },
                            [PSCustomObject]@{ kubernetesVersion = '1.32.4'; isPreview = $false },
                            [PSCustomObject]@{ kubernetesVersion = '1.33.0'; isPreview = $false },
                            [PSCustomObject]@{ kubernetesVersion = '1.33.1'; isPreview = $true }
                        )
                    }
                }
            }
        }

        It 'Returns the highest non-preview patch for 1.32' {
            $result = Resolve-AKSPatchVersion -ResourceGroupName 'rg' -ClusterName 'aks' -MinorVersion '1.32'
            $result | Should -Be '1.32.4'
        }

        It 'Returns the highest non-preview patch for 1.33 (excludes preview)' {
            $result = Resolve-AKSPatchVersion -ResourceGroupName 'rg' -ClusterName 'aks' -MinorVersion '1.33'
            $result | Should -Be '1.33.0'
        }
    }

    Context 'No matching minor version' {

        BeforeEach {
            Mock -ModuleName AKSUpgrade Invoke-AzCli {
                [PSCustomObject]@{
                    controlPlaneProfile = [PSCustomObject]@{
                        upgrades = @(
                            [PSCustomObject]@{ kubernetesVersion = '1.32.0'; isPreview = $false }
                        )
                    }
                }
            }
        }

        It 'Throws when no patches exist for the requested minor' {
            { Resolve-AKSPatchVersion -ResourceGroupName 'rg' -ClusterName 'aks' -MinorVersion '1.34' } |
                Should -Throw '*No available upgrade for minor version 1.34*'
        }
    }

    Context 'Only preview versions available' {

        BeforeEach {
            Mock -ModuleName AKSUpgrade Invoke-AzCli {
                [PSCustomObject]@{
                    controlPlaneProfile = [PSCustomObject]@{
                        upgrades = @(
                            [PSCustomObject]@{ kubernetesVersion = '1.33.0'; isPreview = $true },
                            [PSCustomObject]@{ kubernetesVersion = '1.33.1'; isPreview = $true }
                        )
                    }
                }
            }
        }

        It 'Throws when only preview patches exist' {
            { Resolve-AKSPatchVersion -ResourceGroupName 'rg' -ClusterName 'aks' -MinorVersion '1.33' } |
                Should -Throw '*No available upgrade for minor version 1.33*'
        }
    }
}
