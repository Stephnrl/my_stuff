BeforeAll {
    $modulePath = Join-Path $PSScriptRoot '..'
    Import-Module $modulePath -Force
}

Describe 'Test-AKSClusterHealth' {

    BeforeEach {
        # Suppress log output in tests
        Mock -ModuleName AKSUpgrade Enter-LogGroup {}
        Mock -ModuleName AKSUpgrade Exit-LogGroup {}
        Mock -ModuleName AKSUpgrade Write-Ok {}
        Mock -ModuleName AKSUpgrade Write-Warn {}
        Mock -ModuleName AKSUpgrade Write-Fail {}
    }

    Context 'Healthy cluster' {

        BeforeEach {
            $healthyNodes = @{
                items = @(
                    @{
                        metadata = @{ name = 'node-1' }
                        status   = @{
                            conditions = @(
                                @{ type = 'Ready'; status = 'True' }
                            )
                        }
                    },
                    @{
                        metadata = @{ name = 'node-2' }
                        status   = @{
                            conditions = @(
                                @{ type = 'Ready'; status = 'True' }
                            )
                        }
                    }
                )
            } | ConvertTo-Json -Depth 10

            $healthyPods = @{
                items = @(
                    @{
                        metadata = @{ namespace = 'kube-system'; name = 'coredns-abc' }
                        status   = @{ phase = 'Running' }
                    },
                    @{
                        metadata = @{ namespace = 'default'; name = 'my-app-xyz' }
                        status   = @{ phase = 'Running' }
                    }
                )
            } | ConvertTo-Json -Depth 10

            Mock -CommandName kubectl -MockWith {
                $script:LASTEXITCODE = 0
                if ($args -contains 'nodes') { return $healthyNodes }
                if ($args -contains 'pods')  { return $healthyPods }
            }
        }

        It 'Returns healthy result' {
            $result = Test-AKSClusterHealth
            $result.TotalNodes | Should -Be 2
            $result.SystemPodsHealthy | Should -BeTrue
            $result.WorkloadIssueCount | Should -Be 0
        }
    }

    Context 'Node not ready' {

        BeforeEach {
            $unhealthyNodes = @{
                items = @(
                    @{
                        metadata = @{ name = 'node-1' }
                        status   = @{
                            conditions = @(
                                @{ type = 'Ready'; status = 'True' }
                            )
                        }
                    },
                    @{
                        metadata = @{ name = 'node-2' }
                        status   = @{
                            conditions = @(
                                @{ type = 'Ready'; status = 'False' }
                            )
                        }
                    }
                )
            } | ConvertTo-Json -Depth 10

            Mock -CommandName kubectl -MockWith {
                $script:LASTEXITCODE = 0
                return $unhealthyNodes
            }
        }

        It 'Throws when a node is not Ready' {
            { Test-AKSClusterHealth } | Should -Throw '*Not all nodes are Ready*'
        }
    }

    Context 'System pod failure' {

        BeforeEach {
            $healthyNodes = @{
                items = @(
                    @{
                        metadata = @{ name = 'node-1' }
                        status   = @{ conditions = @(@{ type = 'Ready'; status = 'True' }) }
                    }
                )
            } | ConvertTo-Json -Depth 10

            $failingSystemPods = @{
                items = @(
                    @{
                        metadata = @{ namespace = 'kube-system'; name = 'coredns-abc' }
                        status   = @{ phase = 'CrashLoopBackOff' }
                    }
                )
            } | ConvertTo-Json -Depth 10

            Mock -CommandName kubectl -MockWith {
                $script:LASTEXITCODE = 0
                if ($args -contains 'nodes') { return $healthyNodes }
                if ($args -contains 'pods')  { return $failingSystemPods }
            }
        }

        It 'Throws on kube-system pod failure' {
            { Test-AKSClusterHealth } | Should -Throw '*kube-system pods are unhealthy*'
        }
    }

    Context 'Workload pod issues' {

        BeforeEach {
            $healthyNodes = @{
                items = @(
                    @{
                        metadata = @{ name = 'node-1' }
                        status   = @{ conditions = @(@{ type = 'Ready'; status = 'True' }) }
                    }
                )
            } | ConvertTo-Json -Depth 10

            $mixedPods = @{
                items = @(
                    @{
                        metadata = @{ namespace = 'kube-system'; name = 'coredns-abc' }
                        status   = @{ phase = 'Running' }
                    },
                    @{
                        metadata = @{ namespace = 'default'; name = 'broken-app' }
                        status   = @{ phase = 'Pending' }
                    }
                )
            } | ConvertTo-Json -Depth 10

            Mock -CommandName kubectl -MockWith {
                $script:LASTEXITCODE = 0
                if ($args -contains 'nodes') { return $healthyNodes }
                if ($args -contains 'pods')  { return $mixedPods }
            }
        }

        It 'Warns but succeeds by default' {
            $result = Test-AKSClusterHealth
            $result.WorkloadIssueCount | Should -Be 1
            $result.SystemPodsHealthy | Should -BeTrue
        }

        It 'Throws when -FailOnWorkloadIssues is set' {
            { Test-AKSClusterHealth -FailOnWorkloadIssues } |
                Should -Throw '*Workload pods unhealthy*'
        }
    }
}
