BeforeAll {
    $modulePath = Join-Path $PSScriptRoot '..'
    Import-Module $modulePath -Force
}

Describe 'Get-AKSUpgradePath' {

    Context 'Valid upgrade paths' {

        It 'Returns single hop for adjacent minor versions' {
            $result = Get-AKSUpgradePath -CurrentVersion '1.31.2' -TargetVersion '1.32'
            $result | Should -Be @('1.32')
        }

        It 'Returns two hops for skipping one minor version' {
            $result = Get-AKSUpgradePath -CurrentVersion '1.31.2' -TargetVersion '1.33'
            $result.Count | Should -Be 2
            $result[0] | Should -Be '1.32'
            $result[1] | Should -Be '1.33'
        }

        It 'Returns three hops for 1.28 to 1.31' {
            $result = Get-AKSUpgradePath -CurrentVersion '1.28.0' -TargetVersion '1.31'
            $result.Count | Should -Be 3
            $result | Should -Be @('1.29', '1.30', '1.31')
        }

        It 'Handles current version without patch number' {
            $result = Get-AKSUpgradePath -CurrentVersion '1.31' -TargetVersion '1.33'
            $result | Should -Be @('1.32', '1.33')
        }
    }

    Context 'No upgrade needed' {

        It 'Returns empty array when already at target minor version' {
            $result = Get-AKSUpgradePath -CurrentVersion '1.33.1' -TargetVersion '1.33'
            $result.Count | Should -Be 0
        }

        It 'Returns empty array when current patch differs but minor matches' {
            $result = Get-AKSUpgradePath -CurrentVersion '1.32.0' -TargetVersion '1.32'
            $result.Count | Should -Be 0
        }
    }

    Context 'Error cases' {

        It 'Throws on downgrade attempt' {
            { Get-AKSUpgradePath -CurrentVersion '1.33.1' -TargetVersion '1.31' } |
                Should -Throw '*Downgrades are not supported*'
        }

        It 'Throws on major version mismatch' {
            { Get-AKSUpgradePath -CurrentVersion '1.31.2' -TargetVersion '2.0' } |
                Should -Throw '*Major version mismatch*'
        }
    }
}
