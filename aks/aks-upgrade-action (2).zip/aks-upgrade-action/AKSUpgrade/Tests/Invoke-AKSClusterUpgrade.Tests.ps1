BeforeAll {
    $modulePath = Join-Path $PSScriptRoot '..'
    Import-Module $modulePath -Force
}

Describe 'Invoke-AKSClusterUpgrade' {

    BeforeEach {
        # Suppress logging and sleep in tests
        Mock -ModuleName AKSUpgrade Write-Step {}
        Mock -ModuleName AKSUpgrade Write-Ok {}
        Mock -ModuleName AKSUpgrade Write-Warn {}
        Mock -ModuleName AKSUpgrade Write-Fail {}
        Mock -ModuleName AKSUpgrade Enter-LogGroup {}
        Mock -ModuleName AKSUpgrade Exit-LogGroup {}
        Mock -ModuleName AKSUpgrade Write-ActionOutput {}
        Mock -ModuleName AKSUpgrade Start-Sleep {}

        # Default mock for health checks — always healthy
        Mock -ModuleName AKSUpgrade Test-AKSClusterHealth {
            [PSCustomObject]@{
                TotalNodes         = 2
                SystemPodsHealthy  = $true
                WorkloadIssueCount = 0
            }
        }
    }

    Context 'Two-hop upgrade (1.31 → 1.33)' {

        BeforeEach {
            $callCount = 0

            # Cluster info: returns 1.31.2 initially, then bumps after each hop
            Mock -ModuleName AKSUpgrade Get-AKSClusterInfo {
                $script:callCount++
                $version = switch ($script:callCount) {
                    1       { '1.31.2' }    # Initial query
                    { $_ -le 3 } { '1.32.4' }  # After first hop
                    default { '1.33.2' }    # After second hop
                }
                [PSCustomObject]@{
                    KubernetesVersion = $version
                    NodePools         = @(
                        [PSCustomObject]@{ Name = 'system'; Mode = 'System'; KubernetesVersion = $version; VMSize = 'Standard_D4s_v3'; Count = 2 },
                        [PSCustomObject]@{ Name = 'user1';  Mode = 'User';   KubernetesVersion = $version; VMSize = 'Standard_D8s_v3'; Count = 3 }
                    )
                }
            }

            Mock -ModuleName AKSUpgrade Resolve-AKSPatchVersion {
                param($ResourceGroupName, $ClusterName, $MinorVersion)
                switch ($MinorVersion) {
                    '1.32' { '1.32.4' }
                    '1.33' { '1.33.2' }
                }
            }

            Mock -ModuleName AKSUpgrade Invoke-AKSControlPlaneUpgrade {}
            Mock -ModuleName AKSUpgrade Invoke-AKSNodePoolUpgrade {}
        }

        It 'Performs two hops with correct versions' {
            Invoke-AKSClusterUpgrade `
                -ResourceGroupName 'test-rg' `
                -ClusterName 'test-aks' `
                -TargetVersion '1.33' `
                -ValidationWaitSeconds 0

            # Control plane upgraded twice (once per hop)
            Should -Invoke -ModuleName AKSUpgrade -CommandName Invoke-AKSControlPlaneUpgrade -Times 2 -Exactly
            Should -Invoke -ModuleName AKSUpgrade -CommandName Invoke-AKSControlPlaneUpgrade -ParameterFilter {
                $KubernetesVersion -eq '1.32.4'
            } -Times 1
            Should -Invoke -ModuleName AKSUpgrade -CommandName Invoke-AKSControlPlaneUpgrade -ParameterFilter {
                $KubernetesVersion -eq '1.33.2'
            } -Times 1
        }

        It 'Upgrades each node pool per hop' {
            Invoke-AKSClusterUpgrade `
                -ResourceGroupName 'test-rg' `
                -ClusterName 'test-aks' `
                -TargetVersion '1.33' `
                -ValidationWaitSeconds 0

            # 2 pools × 2 hops = 4 node pool upgrades
            Should -Invoke -ModuleName AKSUpgrade -CommandName Invoke-AKSNodePoolUpgrade -Times 4 -Exactly
        }

        It 'Runs health checks between every step' {
            Invoke-AKSClusterUpgrade `
                -ResourceGroupName 'test-rg' `
                -ClusterName 'test-aks' `
                -TargetVersion '1.33' `
                -ValidationWaitSeconds 0

            # Pre-flight(1) + per hop: post-CP(1) + per-pool(2) = 3 per hop × 2 hops = 6 + 1 = 7
            Should -Invoke -ModuleName AKSUpgrade -CommandName Test-AKSClusterHealth -Times 7
        }

        It 'Writes GitHub Actions outputs' {
            Invoke-AKSClusterUpgrade `
                -ResourceGroupName 'test-rg' `
                -ClusterName 'test-aks' `
                -TargetVersion '1.33' `
                -ValidationWaitSeconds 0

            Should -Invoke -ModuleName AKSUpgrade -CommandName Write-ActionOutput -ParameterFilter {
                $Name -eq 'starting_version' -and $Value -eq '1.31.2'
            }
            Should -Invoke -ModuleName AKSUpgrade -CommandName Write-ActionOutput -ParameterFilter {
                $Name -eq 'status' -and $Value -eq 'completed'
            }
        }
    }

    Context 'Already at target version' {

        BeforeEach {
            Mock -ModuleName AKSUpgrade Get-AKSClusterInfo {
                [PSCustomObject]@{
                    KubernetesVersion = '1.33.2'
                    NodePools         = @(
                        [PSCustomObject]@{ Name = 'system'; Mode = 'System'; KubernetesVersion = '1.33.2'; VMSize = 'Standard_D4s_v3'; Count = 2 }
                    )
                }
            }
        }

        It 'Skips upgrade and outputs status=skipped' {
            Invoke-AKSClusterUpgrade `
                -ResourceGroupName 'test-rg' `
                -ClusterName 'test-aks' `
                -TargetVersion '1.33'

            Should -Invoke -ModuleName AKSUpgrade -CommandName Invoke-AKSControlPlaneUpgrade -Times 0
            Should -Invoke -ModuleName AKSUpgrade -CommandName Invoke-AKSNodePoolUpgrade -Times 0
            Should -Invoke -ModuleName AKSUpgrade -CommandName Write-ActionOutput -ParameterFilter {
                $Name -eq 'status' -and $Value -eq 'skipped'
            }
        }
    }

    Context 'Health check failure mid-upgrade' {

        BeforeEach {
            $healthCallCount = 0

            Mock -ModuleName AKSUpgrade Get-AKSClusterInfo {
                [PSCustomObject]@{
                    KubernetesVersion = '1.31.2'
                    NodePools         = @(
                        [PSCustomObject]@{ Name = 'system'; Mode = 'System'; KubernetesVersion = '1.31.2'; VMSize = 'Standard_D4s_v3'; Count = 2 }
                    )
                }
            }

            Mock -ModuleName AKSUpgrade Resolve-AKSPatchVersion { '1.32.4' }
            Mock -ModuleName AKSUpgrade Invoke-AKSControlPlaneUpgrade {}

            # Fail health check after control plane upgrade
            Mock -ModuleName AKSUpgrade Test-AKSClusterHealth {
                $script:healthCallCount++
                if ($script:healthCallCount -ge 2) {
                    throw "Not all nodes are Ready (1/2 failed)."
                }
                [PSCustomObject]@{ TotalNodes = 2; SystemPodsHealthy = $true; WorkloadIssueCount = 0 }
            }
        }

        It 'Aborts before upgrading node pools' {
            { Invoke-AKSClusterUpgrade `
                -ResourceGroupName 'test-rg' `
                -ClusterName 'test-aks' `
                -TargetVersion '1.32' `
                -ValidationWaitSeconds 0
            } | Should -Throw '*Not all nodes are Ready*'

            Should -Invoke -ModuleName AKSUpgrade -CommandName Invoke-AKSControlPlaneUpgrade -Times 1
            Should -Invoke -ModuleName AKSUpgrade -CommandName Invoke-AKSNodePoolUpgrade -Times 0
        }
    }

    Context 'MaxSurge passthrough' {

        BeforeEach {
            Mock -ModuleName AKSUpgrade Get-AKSClusterInfo {
                [PSCustomObject]@{
                    KubernetesVersion = '1.31.2'
                    NodePools         = @(
                        [PSCustomObject]@{ Name = 'system'; Mode = 'System'; KubernetesVersion = '1.31.2'; VMSize = 'Standard_D4s_v3'; Count = 2 }
                    )
                }
            }
            Mock -ModuleName AKSUpgrade Resolve-AKSPatchVersion { '1.32.4' }
            Mock -ModuleName AKSUpgrade Invoke-AKSControlPlaneUpgrade {}
            Mock -ModuleName AKSUpgrade Invoke-AKSNodePoolUpgrade {}
        }

        It 'Passes MaxSurge to node pool upgrades' {
            Invoke-AKSClusterUpgrade `
                -ResourceGroupName 'test-rg' `
                -ClusterName 'test-aks' `
                -TargetVersion '1.32' `
                -MaxSurge 3 `
                -ValidationWaitSeconds 0

            Should -Invoke -ModuleName AKSUpgrade -CommandName Invoke-AKSNodePoolUpgrade -ParameterFilter {
                $MaxSurge -eq 3
            }
        }
    }
}
