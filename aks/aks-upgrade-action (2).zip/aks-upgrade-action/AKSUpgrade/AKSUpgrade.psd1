@{
    RootModule        = 'AKSUpgrade.psm1'
    ModuleVersion     = '1.0.0'
    GUID              = 'a3f7c2e1-9b4d-4e8f-b6a1-d5c3e7f9a2b4'
    Author            = 'Platform Engineering'
    CompanyName       = 'Internal'
    Description       = 'Safe phased AKS Kubernetes version upgrades with health validation.'
    PowerShellVersion = '7.0'
    CompatiblePSEditions = @('Core')

    FunctionsToExport = @(
        'Get-AKSClusterInfo',
        'Get-AKSUpgradePath',
        'Resolve-AKSPatchVersion',
        'Test-AKSClusterHealth',
        'Invoke-AKSControlPlaneUpgrade',
        'Invoke-AKSNodePoolUpgrade',
        'Invoke-AKSClusterUpgrade'
    )

    CmdletsToExport   = @()
    VariablesToExport  = @()
    AliasesToExport    = @()

    PrivateData = @{
        PSData = @{
            Tags       = @('AKS', 'Kubernetes', 'Azure', 'Upgrade', 'DevOps')
            ProjectUri = ''
        }
    }
}
