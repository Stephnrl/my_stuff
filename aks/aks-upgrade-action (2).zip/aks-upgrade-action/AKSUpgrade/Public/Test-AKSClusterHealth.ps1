function Test-AKSClusterHealth {
    <#
    .SYNOPSIS
        Validates that all nodes are Ready and kube-system pods are healthy.
    .DESCRIPTION
        Checks node readiness and pod health across the cluster. System pod failures
        always throw. Workload pod failures are warnings unless -FailOnWorkloadIssues is set.
    .PARAMETER FailOnWorkloadIssues
        If set, throws when non-system workload pods are unhealthy.
    .OUTPUTS
        PSCustomObject with TotalNodes, SystemPodsHealthy, and WorkloadIssueCount.
    .EXAMPLE
        Test-AKSClusterHealth
        Test-AKSClusterHealth -FailOnWorkloadIssues
    #>
    [CmdletBinding()]
    param(
        [switch] $FailOnWorkloadIssues
    )

    Enter-LogGroup "Cluster Health Check"

    # ── Node readiness ──
    $nodesRaw = kubectl get nodes -o json 2>&1
    if ($LASTEXITCODE -ne 0) { throw "kubectl get nodes failed. Is kubeconfig set?" }
    $nodesJson = $nodesRaw | ConvertFrom-Json

    $totalNodes = $nodesJson.items.Count
    $notReady = $nodesJson.items | Where-Object {
        ($_.status.conditions | Where-Object { $_.type -eq "Ready" }).status -ne "True"
    }

    if ($notReady) {
        $notReady | ForEach-Object { Write-Fail "Node $($_.metadata.name) is NOT Ready" }
        Exit-LogGroup
        throw "Not all nodes are Ready ($($notReady.Count)/$totalNodes failed)."
    }
    Write-Ok "All $totalNodes node(s) are Ready."

    # ── Pod health ──
    $podsRaw = kubectl get pods --all-namespaces -o json 2>&1
    if ($LASTEXITCODE -ne 0) { throw "kubectl get pods failed." }
    $podsJson = $podsRaw | ConvertFrom-Json

    # System pods
    $systemFailing = $podsJson.items | Where-Object {
        $_.metadata.namespace -eq "kube-system" -and
        $_.status.phase -notin @("Running", "Succeeded")
    }
    if ($systemFailing.Count -gt 0) {
        $systemFailing | ForEach-Object {
            Write-Fail "kube-system/$($_.metadata.name) — $($_.status.phase)"
        }
        Exit-LogGroup
        throw "Critical kube-system pods are unhealthy ($($systemFailing.Count) failing)."
    }
    Write-Ok "All kube-system pods healthy."

    # Workload pods
    $workloadFailing = $podsJson.items | Where-Object {
        $_.metadata.namespace -ne "kube-system" -and
        $_.status.phase -notin @("Running", "Succeeded")
    }
    if ($workloadFailing.Count -gt 0) {
        Write-Warn "$($workloadFailing.Count) workload pod(s) not in Running/Succeeded state:"
        $workloadFailing | Select-Object -First 10 | ForEach-Object {
            Write-Warn "  $($_.metadata.namespace)/$($_.metadata.name) — $($_.status.phase)"
        }
        if ($FailOnWorkloadIssues) {
            Exit-LogGroup
            throw "Workload pods unhealthy and -FailOnWorkloadIssues is set."
        }
    }
    else {
        Write-Ok "All workload pods healthy."
    }

    Exit-LogGroup

    return [PSCustomObject]@{
        TotalNodes         = $totalNodes
        SystemPodsHealthy  = $true
        WorkloadIssueCount = $workloadFailing.Count
    }
}
