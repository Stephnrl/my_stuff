function Invoke-AKSNodePoolUpgrade {
    <#
    .SYNOPSIS
        Upgrades a single AKS node pool to the specified version.
    .PARAMETER ResourceGroupName
        Azure resource group.
    .PARAMETER ClusterName
        AKS cluster name.
    .PARAMETER NodePoolName
        Name of the node pool to upgrade.
    .PARAMETER KubernetesVersion
        Target Kubernetes version (full patch version, e.g., "1.32.4").
    .PARAMETER MaxSurge
        Maximum number of extra nodes created during rolling upgrade. Default: 1.
    .EXAMPLE
        Invoke-AKSNodePoolUpgrade -ResourceGroupName "rg" -ClusterName "aks" -NodePoolName "system" -KubernetesVersion "1.32.4"
    #>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)] [string] $ResourceGroupName,
        [Parameter(Mandatory)] [string] $ClusterName,
        [Parameter(Mandatory)] [string] $NodePoolName,
        [Parameter(Mandatory)] [string] $KubernetesVersion,
        [int] $MaxSurge = 1
    )

    if (-not $PSCmdlet.ShouldProcess("$ClusterName/$NodePoolName", "Upgrade node pool to $KubernetesVersion")) {
        return
    }

    Enter-LogGroup "Node Pool '$NodePoolName' Upgrade → $KubernetesVersion"

    Invoke-AzCli -Arguments @(
        'aks', 'nodepool', 'upgrade',
        '-g', $ResourceGroupName,
        '--cluster-name', $ClusterName,
        '--name', $NodePoolName,
        '--kubernetes-version', $KubernetesVersion,
        '--max-surge', $MaxSurge.ToString(),
        '--yes'
    ) -RawOutput -ErrorMessage "Node pool '$NodePoolName' upgrade to $KubernetesVersion failed."

    Write-Ok "Node pool '$NodePoolName' upgraded to $KubernetesVersion."
    Exit-LogGroup
}
