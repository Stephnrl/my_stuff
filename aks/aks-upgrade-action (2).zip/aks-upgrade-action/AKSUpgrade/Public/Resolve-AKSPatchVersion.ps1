function Resolve-AKSPatchVersion {
    <#
    .SYNOPSIS
        Finds the highest non-preview patch version available for a given minor version.
    .PARAMETER ResourceGroupName
        Azure resource group.
    .PARAMETER ClusterName
        AKS cluster name.
    .PARAMETER MinorVersion
        Minor version to resolve (e.g., "1.32").
    .OUTPUTS
        String — Full patch version (e.g., "1.32.4").
    .EXAMPLE
        Resolve-AKSPatchVersion -ResourceGroupName "rg" -ClusterName "aks" -MinorVersion "1.32"
        # Returns: "1.32.4"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [string] $ResourceGroupName,
        [Parameter(Mandatory)] [string] $ClusterName,
        [Parameter(Mandatory)] [string] $MinorVersion
    )

    $upgradeData = Invoke-AzCli -Arguments @(
        'aks', 'get-upgrades',
        '-g', $ResourceGroupName,
        '-n', $ClusterName,
        '-o', 'json'
    ) -ErrorMessage "Failed to fetch available upgrades."

    $candidates = $upgradeData.controlPlaneProfile.upgrades |
        Where-Object { -not $_.isPreview } |
        ForEach-Object { $_.kubernetesVersion } |
        Where-Object { $_ -like "$MinorVersion.*" } |
        Sort-Object { [version]$_ } -Descending

    if (-not $candidates) {
        $available = $upgradeData.controlPlaneProfile.upgrades |
            Where-Object { -not $_.isPreview } |
            ForEach-Object { $_.kubernetesVersion }
        throw "No available upgrade for minor version $MinorVersion. Available versions: $($available -join ', ')"
    }

    return $candidates[0]
}
