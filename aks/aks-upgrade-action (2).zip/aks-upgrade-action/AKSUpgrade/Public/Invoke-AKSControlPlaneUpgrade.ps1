function Invoke-AKSControlPlaneUpgrade {
    <#
    .SYNOPSIS
        Upgrades only the AKS control plane to the specified version.
    .PARAMETER ResourceGroupName
        Azure resource group.
    .PARAMETER ClusterName
        AKS cluster name.
    .PARAMETER KubernetesVersion
        Target Kubernetes version (full patch version, e.g., "1.32.4").
    .EXAMPLE
        Invoke-AKSControlPlaneUpgrade -ResourceGroupName "rg" -ClusterName "aks" -KubernetesVersion "1.32.4"
    #>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)] [string] $ResourceGroupName,
        [Parameter(Mandatory)] [string] $ClusterName,
        [Parameter(Mandatory)] [string] $KubernetesVersion
    )

    if (-not $PSCmdlet.ShouldProcess($ClusterName, "Upgrade control plane to $KubernetesVersion")) {
        return
    }

    Enter-LogGroup "Control Plane Upgrade → $KubernetesVersion"

    Invoke-AzCli -Arguments @(
        'aks', 'upgrade',
        '-g', $ResourceGroupName,
        '-n', $ClusterName,
        '--kubernetes-version', $KubernetesVersion,
        '--control-plane-only',
        '--yes'
    ) -RawOutput -ErrorMessage "Control plane upgrade to $KubernetesVersion failed."

    Write-Ok "Control plane upgraded to $KubernetesVersion."
    Exit-LogGroup
}
