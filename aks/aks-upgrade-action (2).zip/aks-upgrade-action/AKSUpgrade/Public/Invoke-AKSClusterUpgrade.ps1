function Invoke-AKSClusterUpgrade {
    <#
    .SYNOPSIS
        Orchestrates a full phased AKS upgrade across one or more minor versions.
    .DESCRIPTION
        For each minor version hop:
          1. Resolves the highest available patch version
          2. Upgrades the control plane
          3. Validates cluster health
          4. Upgrades each node pool one at a time
          5. Validates cluster health after each node pool

        Emits GitHub Actions outputs (starting_version, final_version, upgrade_path, status)
        when running in a GitHub Actions environment.
    .PARAMETER ResourceGroupName
        Azure resource group.
    .PARAMETER ClusterName
        AKS cluster name.
    .PARAMETER TargetVersion
        Target Kubernetes minor version (e.g., "1.33").
    .PARAMETER MaxSurge
        Max surge for node pool rolling upgrades. Default: 1.
    .PARAMETER ValidationWaitSeconds
        Seconds to wait after each step for stabilization. Default: 120.
    .PARAMETER FailOnWorkloadIssues
        If set, abort if non-system workload pods are unhealthy during validation.
    .EXAMPLE
        Invoke-AKSClusterUpgrade -ResourceGroupName "rg" -ClusterName "aks" -TargetVersion "1.33"
    .EXAMPLE
        # Fast upgrade with higher surge, shorter waits
        Invoke-AKSClusterUpgrade -ResourceGroupName "rg" -ClusterName "aks" -TargetVersion "1.33" -MaxSurge 3 -ValidationWaitSeconds 60
    #>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)] [string] $ResourceGroupName,
        [Parameter(Mandatory)] [string] $ClusterName,
        [Parameter(Mandatory)] [string] $TargetVersion,
        [int]    $MaxSurge = 1,
        [int]    $ValidationWaitSeconds = 120,
        [switch] $FailOnWorkloadIssues
    )

    $ErrorActionPreference = "Stop"

    # ── Gather info ──
    Write-Step "Gathering cluster info..."
    $info = Get-AKSClusterInfo -ResourceGroupName $ResourceGroupName -ClusterName $ClusterName
    Write-Ok "Current version: $($info.KubernetesVersion)"
    Write-Ok "Node pools: $(($info.NodePools | ForEach-Object { "$($_.Name) ($($_.Mode))" }) -join ', ')"

    # ── Build path ──
    $upgradePath = Get-AKSUpgradePath -CurrentVersion $info.KubernetesVersion -TargetVersion $TargetVersion
    if ($upgradePath.Count -eq 0) {
        Write-Ok "No upgrade needed."
        Write-ActionOutput -Name "status" -Value "skipped"
        Write-ActionOutput -Name "starting_version" -Value $info.KubernetesVersion
        Write-ActionOutput -Name "final_version" -Value $info.KubernetesVersion
        return
    }
    Write-Ok "Upgrade path: $($info.KubernetesVersion) → $($upgradePath -join ' → ')"

    # ── Pre-flight health check ──
    Test-AKSClusterHealth -FailOnWorkloadIssues:$FailOnWorkloadIssues

    # ── GitHub Actions outputs ──
    Write-ActionOutput -Name "upgrade_path" -Value ($upgradePath -join ',')
    Write-ActionOutput -Name "starting_version" -Value $info.KubernetesVersion

    # ── Execute each hop ──
    $hopCount = 0
    foreach ($minorTarget in $upgradePath) {
        $hopCount++
        Write-Host "`n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Magenta
        Write-Host "  HOP $hopCount/$($upgradePath.Count) → $minorTarget" -ForegroundColor Magenta
        Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Magenta

        # Resolve exact patch version
        $patchVersion = Resolve-AKSPatchVersion `
            -ResourceGroupName $ResourceGroupName `
            -ClusterName $ClusterName `
            -MinorVersion $minorTarget
        Write-Ok "Resolved patch version: $patchVersion"

        # ── Control plane ──
        Invoke-AKSControlPlaneUpgrade `
            -ResourceGroupName $ResourceGroupName `
            -ClusterName $ClusterName `
            -KubernetesVersion $patchVersion

        Write-Step "Waiting ${ValidationWaitSeconds}s for control plane stabilization..."
        Start-Sleep -Seconds $ValidationWaitSeconds
        Test-AKSClusterHealth -FailOnWorkloadIssues:$FailOnWorkloadIssues

        # ── Node pools (one at a time) ──
        foreach ($pool in $info.NodePools) {
            Invoke-AKSNodePoolUpgrade `
                -ResourceGroupName $ResourceGroupName `
                -ClusterName $ClusterName `
                -NodePoolName $pool.Name `
                -KubernetesVersion $patchVersion `
                -MaxSurge $MaxSurge

            Write-Step "Waiting ${ValidationWaitSeconds}s for node pool '$($pool.Name)' stabilization..."
            Start-Sleep -Seconds $ValidationWaitSeconds
            Test-AKSClusterHealth -FailOnWorkloadIssues:$FailOnWorkloadIssues
        }

        # Verify hop completed
        $postHopInfo = Get-AKSClusterInfo -ResourceGroupName $ResourceGroupName -ClusterName $ClusterName
        Write-Ok "Hop $hopCount complete — cluster now at $($postHopInfo.KubernetesVersion)"
    }

    # ── Final summary ──
    $finalInfo = Get-AKSClusterInfo -ResourceGroupName $ResourceGroupName -ClusterName $ClusterName
    Write-ActionOutput -Name "final_version" -Value $finalInfo.KubernetesVersion
    Write-ActionOutput -Name "status" -Value "completed"

    Write-Host "`n═══════════════════════════════════════════════════════" -ForegroundColor Green
    Write-Host "  ✔ UPGRADE COMPLETE" -ForegroundColor Green
    Write-Host "  Cluster $ClusterName is now running $($finalInfo.KubernetesVersion)" -ForegroundColor Green
    Write-Host "═══════════════════════════════════════════════════════" -ForegroundColor Green
}
