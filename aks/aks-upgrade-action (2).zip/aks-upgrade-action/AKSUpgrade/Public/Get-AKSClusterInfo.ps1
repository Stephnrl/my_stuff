function Get-AKSClusterInfo {
    <#
    .SYNOPSIS
        Returns current cluster version and node pool details.
    .PARAMETER ResourceGroupName
        Azure resource group.
    .PARAMETER ClusterName
        AKS cluster name.
    .OUTPUTS
        PSCustomObject with KubernetesVersion and NodePools properties.
    .EXAMPLE
        $info = Get-AKSClusterInfo -ResourceGroupName "my-rg" -ClusterName "my-aks"
        $info.KubernetesVersion  # "1.31.2"
        $info.NodePools          # Array of pool objects
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [string] $ResourceGroupName,
        [Parameter(Mandatory)] [string] $ClusterName
    )

    $version = Invoke-AzCli -Arguments @(
        'aks', 'show',
        '-g', $ResourceGroupName,
        '-n', $ClusterName,
        '--query', 'kubernetesVersion',
        '-o', 'tsv'
    ) -RawOutput -ErrorMessage "Failed to query cluster '$ClusterName'."

    $poolsData = Invoke-AzCli -Arguments @(
        'aks', 'nodepool', 'list',
        '-g', $ResourceGroupName,
        '--cluster-name', $ClusterName,
        '-o', 'json'
    ) -ErrorMessage "Failed to list node pools for '$ClusterName'."

    $pools = $poolsData | ForEach-Object {
        [PSCustomObject]@{
            Name              = $_.name
            KubernetesVersion = $_.currentOrchestratorVersion
            VMSize            = $_.vmSize
            Count             = $_.count
            Mode              = $_.mode
        }
    }

    return [PSCustomObject]@{
        KubernetesVersion = $version.Trim()
        NodePools         = $pools
    }
}
