function Get-AKSUpgradePath {
    <#
    .SYNOPSIS
        Computes the hop-by-hop minor version upgrade path.
    .DESCRIPTION
        AKS requires upgrading one minor version at a time. This function returns
        an ordered array of minor version strings to traverse from current to target.
    .PARAMETER CurrentVersion
        The current Kubernetes version (e.g., "1.31.2" or "1.31").
    .PARAMETER TargetVersion
        The target Kubernetes minor version (e.g., "1.33").
    .OUTPUTS
        String[] — Array of minor version strings (e.g., @("1.32", "1.33")).
        Returns empty array if no upgrade is needed.
    .EXAMPLE
        Get-AKSUpgradePath -CurrentVersion "1.31.2" -TargetVersion "1.33"
        # Returns: @("1.32", "1.33")
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [string] $CurrentVersion,
        [Parameter(Mandatory)] [string] $TargetVersion
    )

    $currentParts = $CurrentVersion.Split('.')
    $targetParts  = $TargetVersion.Split('.')

    if ($currentParts[0] -ne $targetParts[0]) {
        throw "Major version mismatch: current=$($currentParts[0]), target=$($targetParts[0]). Cross-major upgrades are not supported."
    }

    $currentMinor = [int]$currentParts[1]
    $targetMinor  = [int]$targetParts[1]

    if ($currentMinor -gt $targetMinor) {
        throw "Target version $TargetVersion is older than current $CurrentVersion. Downgrades are not supported."
    }

    if ($currentMinor -eq $targetMinor) {
        Write-Ok "Cluster is already at minor version 1.$currentMinor — no hop needed."
        return @()
    }

    $path = @()
    for ($m = $currentMinor + 1; $m -le $targetMinor; $m++) {
        $path += "1.$m"
    }

    return $path
}
